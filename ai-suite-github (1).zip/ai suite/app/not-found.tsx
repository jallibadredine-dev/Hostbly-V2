"use client";

import { usePathname } from "next/navigation";
import { useEffect } from "react";
import Link from "next/link";

export default function NotFound() {
    const pathname = usePathname();

    useEffect(() => {
        console.warn("404 Warning: User attempted to access non-existent route:", pathname);
    }, [pathname]);

    return (
        <div className="flex min-h-screen items-center justify-center bg-gray-100 dark:bg-gray-900">
            <div className="text-center">
                <h1 className="mb-4 text-4xl font-bold bg-gradient-to-r from-primary to-ai-accent bg-clip-text text-transparent">404</h1>
                <p className="mb-4 text-xl text-muted-foreground">Oops! Page not found</p>
                <Link href="/" className="text-primary underline hover:text-primary/80 transition-colors">
                    Return to Home
                </Link>
            </div>
        </div>
    );
}
