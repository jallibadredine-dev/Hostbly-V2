"use client";

import React, { createContext, useContext, useEffect, useState } from "react"
import { useSettings } from "@/contexts/SettingsContext";

type Theme = "dark" | "light" | "system"

type ThemeProviderProps = {
  children: React.ReactNode
  defaultTheme?: Theme
  storageKey?: string
}

type ThemeProviderState = {
  theme: Theme
  setTheme: (theme: Theme) => void
}

const initialState: ThemeProviderState = {
  theme: "system",
  setTheme: () => null,
}

const ThemeProviderContext = createContext<ThemeProviderState>(initialState)

export function ThemeProvider({
  children,
  defaultTheme = "system",
  storageKey = "vite-ui-theme",
  ...props
}: ThemeProviderProps) {
  const { settings } = useSettings();

  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window !== "undefined") {
      const storedTheme = localStorage.getItem(storageKey) as Theme;
      if (storedTheme) return storedTheme;
    }
    return defaultTheme;
  });

  // Effect to apply defaultTheme from settings if no local theme is set
  useEffect(() => {
    if (settings?.metadata?.defaultTheme && typeof window !== "undefined") {
      const storedTheme = window.localStorage.getItem(storageKey);
      if (!storedTheme && settings.metadata.defaultTheme !== defaultTheme) {
        setTheme(settings.metadata.defaultTheme as Theme);
      }
    }
  }, [settings?.metadata?.defaultTheme, defaultTheme, storageKey]);

  useEffect(() => {
    const root = window.document.documentElement;

    const applyTheme = (targetTheme: "light" | "dark") => {
      root.classList.remove("light", "dark");
      root.classList.add(targetTheme);
      root.style.colorScheme = targetTheme;
    };

    if (theme === "system") {
      const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
      applyTheme(mediaQuery.matches ? "dark" : "light");

      const listener = (e: MediaQueryListEvent) => {
        applyTheme(e.matches ? "dark" : "light");
      };

      mediaQuery.addEventListener("change", listener);
      return () => mediaQuery.removeEventListener("change", listener);
    } else {
      applyTheme(theme);
    }
  }, [theme]);

  const value = {
    theme,
    setTheme: (theme: Theme) => {
      localStorage.setItem(storageKey, theme)
      setTheme(theme)
    },
  }

  return (
    <ThemeProviderContext.Provider {...props} value={value}>
      {children}
    </ThemeProviderContext.Provider>
  )
}

export const useTheme = () => {
  const context = useContext(ThemeProviderContext)

  if (context === undefined)
    throw new Error("useTheme must be used within a ThemeProvider")

  return context
}
